const API_BASE = '/api/v1';

let authToken = localStorage.getItem('token') || '';
let currentUser = JSON.parse(localStorage.getItem('user') || 'null');
let pendingEmail = '';

// DOM Elements
const toast = document.getElementById('toast');
const authSection = document.getElementById('authSection');
const protectedContent = document.getElementById('protectedContent');
const adminSection = document.getElementById('adminSection');
const userInfo = document.getElementById('userInfo');
const loginForm = document.getElementById('loginForm');
const otpForm = document.getElementById('otpForm');
const registerForm = document.getElementById('registerForm');
const btnRequestOtpOnly = document.getElementById('btnRequestOtpOnly');
const addWineForm = document.getElementById('addWineForm');
const editWineForm = document.getElementById('editWineForm');
const editWineModal = document.getElementById('editWineModal');
const closeEditWine = document.getElementById('closeEditWine');
const tabLogin = document.getElementById('tabLogin');
const tabRegister = document.getElementById('tabRegister');
const wineGrid = document.getElementById('wineGrid');
const myOrdersBtn = document.getElementById('myOrdersBtn');
const ordersModal = document.getElementById('ordersModal');
const closeOrders = document.getElementById('closeOrders');
const ordersList = document.getElementById('ordersList');

// Cart Elements
const cartBtn = document.getElementById('cartBtn');
const cartDrawer = document.getElementById('cartDrawer');
const cartOverlay = document.getElementById('cartOverlay');
const closeCart = document.getElementById('closeCart');
const cartItemsList = document.getElementById('cartItemsList');
const cartTotal = document.getElementById('cartTotal');
const cartCount = document.getElementById('cartCount');
const checkoutBtn = document.getElementById('checkoutBtn');

function showToast(message, isError = false) {
  toast.innerText = message;
  toast.className = `toast ${isError ? 'error' : ''}`;
  toast.style.display = 'block';
  setTimeout(() => { toast.style.display = 'none'; }, 3500);
}

document.addEventListener('DOMContentLoaded', () => {
  updateUserUI();
  if (authToken) {
    fetchWines();
    fetchCart();
  }
});

// Tab Switchers
tabLogin.addEventListener('click', () => {
  tabLogin.classList.add('active');
  tabRegister.classList.remove('active');
  loginForm.classList.add('active');
  otpForm.classList.remove('active');
  registerForm.classList.remove('active');
});

tabRegister.addEventListener('click', () => {
  tabRegister.classList.add('active');
  tabLogin.classList.remove('active');
  registerForm.classList.add('active');
  loginForm.classList.remove('active');
  otpForm.classList.remove('active');
});

function updateUserUI() {
  if (currentUser && authToken) {
    authSection.style.display = 'none';
    protectedContent.style.display = 'block';
    myOrdersBtn.style.display = 'inline-block';
    cartBtn.style.display = 'flex';

    userInfo.innerHTML = `
      <span>שלום, <strong>${currentUser.full_name}</strong> ${currentUser.role === 'admin' ? '<small style="color:var(--gold);">(מנהל)</small>' : ''}</span>
      <button id="logoutBtn" style="background:rgba(255,255,255,0.15); color:#fff; border:1px solid rgba(255,255,255,0.3); padding:4px 10px; border-radius:15px; cursor:pointer;">התנתק</button>
    `;
    document.getElementById('logoutBtn').addEventListener('click', logout);

    if (currentUser.role === 'admin' && adminSection) {
      adminSection.style.display = 'block';
    } else if (adminSection) {
      adminSection.style.display = 'none';
    }
  } else {
    authSection.style.display = 'block';
    protectedContent.style.display = 'none';
    myOrdersBtn.style.display = 'none';
    cartBtn.style.display = 'none';
    if (adminSection) adminSection.style.display = 'none';
    userInfo.innerHTML = '<span style="color:#ddd;">אורח</span>';
  }
}

// 1. התחברות רגילה עם סיסמה (כניסה ישירה ללא דרך חתחתים)
loginForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const email = document.getElementById('loginEmail').value;
  const password = document.getElementById('loginPassword').value;

  if (!password) {
    showToast('אנא הזן סיסמה להתחברות', true);
    return;
  }

  try {
    const res = await fetch(`${API_BASE}/users/login`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email, password })
    });
    const data = await res.json();

    if (res.ok) {
      // אם השרת דורש קוד OTP בכל זאת
      if (data.requiresOtp) {
        pendingEmail = email;
        loginForm.classList.remove('active');
        otpForm.classList.add('active');
        if (data.debugCode) {
          showToast(`קוד אימות להתחברות: ${data.debugCode}`);
        } else {
          showToast('קוד האימות נשלח לתיבת המייל שלך');
        }
        return;
      }

      // התחברות ישירה מוצלחת
      authToken = data.token;
      currentUser = data.user;
      localStorage.setItem('token', authToken);
      localStorage.setItem('user', JSON.stringify(currentUser));
      updateUserUI();
      fetchWines();
      fetchCart();
      showToast('התחברת בהצלחה!');
    } else {
      showToast(data.message || 'אימייל או סיסמה שגויים', true);
    }
  } catch (err) {
    showToast('תקלה בתקשורת עם השרת', true);
  }
});

// 2. התחברות בלחיצה על "שלח לי קוד אימות ללא סיסמה" בלבד
if (btnRequestOtpOnly) {
  btnRequestOtpOnly.addEventListener('click', async () => {
    const email = document.getElementById('loginEmail').value;
    if (!email) {
      showToast('אנא הזן כתובת אימייל תחילה', true);
      return;
    }

    try {
      const res = await fetch(`${API_BASE}/users/request-otp-only`, {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ email })
      });
      const data = await res.json();

      if (res.ok && data.requiresOtp) {
        pendingEmail = email;
        loginForm.classList.remove('active');
        otpForm.classList.add('active');
        if (data.debugCode) {
          showToast(`קוד אימות לבדיקה: ${data.debugCode}`);
        } else {
          showToast('קוד האימות נשלח לתיבת המייל שלך');
        }
      } else {
        showToast(data.message || 'שגיאה בשליחת הקוד', true);
      }
    } catch (err) {
      showToast('תקלה בתקשורת עם השרת', true);
    }
  });
}

// 3. אימות קוד OTP
otpForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const code = document.getElementById('otpCode').value;

  try {
    const res = await fetch(`${API_BASE}/users/verify-otp`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ email: pendingEmail, code })
    });
    const data = await res.json();

    if (res.ok) {
      authToken = data.token;
      currentUser = data.user;
      localStorage.setItem('token', authToken);
      localStorage.setItem('user', JSON.stringify(currentUser));
      updateUserUI();
      fetchWines();
      fetchCart();
      showToast('התחברת בהצלחה!');
    } else {
      showToast(data.message || 'קוד לא תקין', true);
    }
  } catch (err) {
    showToast('תקלה באימות הקוד', true);
  }
});

// 4. הרשמה
registerForm.addEventListener('submit', async (e) => {
  e.preventDefault();
  const id = document.getElementById('regId').value;
  const full_name = document.getElementById('regName').value;
  const email = document.getElementById('regEmail').value;
  const password = document.getElementById('regPassword').value;
  const phone = document.getElementById('regPhone').value;
  const address = document.getElementById('regAddress').value;

  try {
    const res = await fetch(`${API_BASE}/users`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ id, full_name, email, password, phone, address })
    });
    const data = await res.json();

    if (res.ok) {
      authToken = data.token;
      currentUser = data.user;
      localStorage.setItem('token', authToken);
      localStorage.setItem('user', JSON.stringify(currentUser));
      updateUserUI();
      fetchWines();
      fetchCart();
      showToast('נרשמת בהצלחה!');
    } else {
      showToast(data.message || 'שגיאה בהרשמה', true);
    }
  } catch (err) {
    showToast('תקלה בתקשורת', true);
  }
});

function logout() {
  authToken = '';
  currentUser = null;
  localStorage.removeItem('token');
  localStorage.removeItem('user');
  updateUserUI();
  cartCount.innerText = '0';
  showToast('התנתקת מהחשבון');
}

// 5. טעינת קטלוג יינות
async function fetchWines() {
  try {
    const res = await fetch(`${API_BASE}/wines`);
    const wines = await res.json();

    wineGrid.innerHTML = wines.map(w => {
      const cleanName = (w.name || '').replace(/'/g, "\\'").replace(/"/g, '&quot;');
      const cleanDesc = (w.description || '').replace(/'/g, "\\'").replace(/"/g, '&quot;');

      return `
        <div class="wine-card">
          <div>
            <h3 class="wine-title">${w.name}</h3>
            <p class="wine-desc">${w.description || 'יין בוטיק איכותי'}</p>
            <div class="wine-tags">
              <span class="tag">${w.type}</span>
              <span class="tag">${w.sweetness}</span>
              <span class="tag">במלאי: ${w.stock_quantity}</span>
            </div>
          </div>
          <div>
            <div class="wine-footer">
              <span class="wine-price">${w.price} ₪</span>
              <button class="btn-add-cart" onclick="addToCart(${w.id})" ${w.stock_quantity === 0 ? 'disabled' : ''}>
                ${w.stock_quantity === 0 ? 'אזל' : 'הוסף לסל 🛒'}
              </button>
            </div>
            ${currentUser && currentUser.role === 'admin' ? `
              <button style="background:none; border:none; color:var(--wine-main); text-decoration:underline; cursor:pointer; margin-top:10px; font-size:0.9rem; font-weight:bold;" onclick="openEditWineModal(${w.id}, '${cleanName}',${w.price}, ${w.stock_quantity}, '${cleanDesc}')">
                ✏️ ערוך יין
              </button>
            ` : ''}
          </div>
        </div>
      `;
    }).join('');
  } catch (err) {
    console.error(err);
  }
}

// 6. עריכת יין מנהל - פתיחת מודל ושמירה ב-Database
window.openEditWineModal = function(id, name, price, stock, desc) {
  document.getElementById('editWineId').value = id;
  document.getElementById('editWineName').value = name;
  document.getElementById('editWinePrice').value = price;
  document.getElementById('editWineStock').value = stock;
  document.getElementById('editWineDesc').value = desc;
  editWineModal.style.display = 'flex';
};

if (editWineForm) {
  editWineForm.addEventListener('submit', async (e) => {
    e.preventDefault();
    const id = document.getElementById('editWineId').value;

    const updatedData = {
      name: document.getElementById('editWineName').value,
      price: parseFloat(document.getElementById('editWinePrice').value),
      stock_quantity: parseInt(document.getElementById('editWineStock').value, 10),
      description: document.getElementById('editWineDesc').value
    };

    try {
      const res = await fetch(`${API_BASE}/wines/${id}`, {
        method: 'PUT',
        headers: {
          'Content-Type': 'application/json',
          'Authorization': `Bearer ${authToken}`
        },
        body: JSON.stringify(updatedData)
      });

      if (res.ok) {
        showToast('היין עודכן ונשמר בהצלחה!');
        editWineModal.style.display = 'none';
        fetchWines(); // רענון מידי של התצוגה
      } else {
        const err = await res.json();
        showToast(err.message || 'שגיאה בעדכון היין', true);
      }
    } catch (err) {
      showToast('תקלה בתקשורת עם השרת', true);
    }
  });
}

if (closeEditWine) {
  closeEditWine.addEventListener('click', () => { editWineModal.style.display = 'none'; });
}

// 7. הוספה לסל
async function addToCart(wineId) {
  try {
    const res = await fetch(`${API_BASE}/cart`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${authToken}` },
      body: JSON.stringify({ wine_id: wineId, quantity: 1, increment: true })
    });

    if (res.ok) {
      showToast('היין נוסף לסל הקניות!');
      await fetchCart();
      cartDrawer.classList.add('open');
      cartOverlay.classList.add('open');
    } else {
      const err = await res.json();
      showToast(err.message || 'שגיאה בהוספה לסל', true);
    }
  } catch (err) {
    console.error(err);
  }
}

// עדכון כמות בסל (+ / -)
async function updateCartQuantity(wineId, newQty) {
  if (newQty <= 0) return;

  try {
    const res = await fetch(`${API_BASE}/cart`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${authToken}` },
      body: JSON.stringify({ wine_id: wineId, quantity: newQty, increment: false })
    });

    if (res.ok) fetchCart();
  } catch (err) {
    console.error(err);
  }
}

// 8. טעינת סל קניות
async function fetchCart() {
  if (!authToken) return;

  try {
    const res = await fetch(`${API_BASE}/cart`, {
      headers: { 'Authorization': `Bearer ${authToken}` }
    });
    if (!res.ok) return;

    const cart = await res.json();
    cartCount.innerText = cart.reduce((sum, item) => sum + item.quantity, 0);

    let total = 0;
    cartItemsList.innerHTML = cart.length === 0 
      ? '<p style="text-align:center; color:#888; margin-top:30px;">הסל שלך ריק כרגע</p>' 
      : cart.map(item => {
        const itemTotal = item.quantity * item.Wine.price;
        total += itemTotal;
        return `
          <div class="cart-row">
            <div>
              <strong>${item.Wine.name}</strong><br>
              <small style="color:#777;">${item.Wine.price} ₪</small>
            </div>
            <div class="cart-controls">
              <button class="btn-qty" onclick="updateCartQuantity(${item.wine_id}, ${item.quantity - 1})">-</button>
              <span>${item.quantity}</span>
              <button class="btn-qty" onclick="updateCartQuantity(${item.wine_id}, ${item.quantity + 1})">+</button>
              <span style="font-weight:bold; margin-right:5px;">${itemTotal} ₪</span>
              <button style="background:none; border:none; cursor:pointer; color:#e74c3c;" onclick="removeFromCart(${item.id})">🗑</button>
            </div>
          </div>
        `;
      }).join('');

    cartTotal.innerText = total;
  } catch (err) {
    console.error(err);
  }
}

// הסרת פריט מהסל
async function removeFromCart(cartItemId) {
  try {
    const res = await fetch(`${API_BASE}/cart/${cartItemId}`, {
      method: 'DELETE',
      headers: { 'Authorization': `Bearer ${authToken}` }
    });

    if (res.ok) {
      showToast('הפריט הוסר מהסל');
      fetchCart();
    }
  } catch (err) {
    console.error(err);
  }
}

// ביצוע הזמנה בקופה
checkoutBtn.addEventListener('click', async () => {
  try {
    const res = await fetch(`${API_BASE}/orders`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json', 'Authorization': `Bearer ${authToken}` },
      body: JSON.stringify({ shipping_address: currentUser.address || 'כתובת למשלוח' })
    });

    if (res.ok) {
      showToast('🎉 ההזמנה בוצעה בהצלחה!');
      cartDrawer.classList.remove('open');
      cartOverlay.classList.remove('open');
      fetchCart();
      fetchWines();
    } else {
      const data = await res.json();
      showToast(data.message || 'שגיאה בביצוע ההזמנה', true);
    }
  } catch (err) {
    console.error(err);
  }
});

// היסטוריית הזמנות
myOrdersBtn.addEventListener('click', async () => {
  try {
    const res = await fetch(`${API_BASE}/orders/my-orders`, {
      headers: { 'Authorization': `Bearer ${authToken}` }
    });
    const orders = await res.json();

    if (orders.length === 0) {
      ordersList.innerHTML = '<p style="text-align:center;">עדיין לא ביצעת הזמנות בחנות</p>';
    } else {
      ordersList.innerHTML = orders.map(o => `
        <div style="border-bottom:1px solid #eee; padding:12px 0;">
          <div style="display:flex; justify-content:space-between;">
            <strong>הזמנה #${o.id}</strong>
            <span style="color:var(--wine-main); font-weight:bold;">${o.total_price} ₪</span>
          </div>
          <small style="color:#666;">תאריך: ${new Date(o.createdAt).toLocaleDateString('he-IL')} | סטטוס: ${o.status}</small>
          <div style="margin-top:5px; font-size:0.85rem; color:#444;">
            ${o.OrderItems.map(i => `${i.Wine ? i.Wine.name : 'יין'} (${i.quantity} יח')`).join(', ')}
          </div>
        </div>
      `).join('');
    }
    ordersModal.style.display = 'flex';
  } catch (err) {
    console.error(err);
  }
});

if (closeOrders) {
  closeOrders.addEventListener('click', () => { ordersModal.style.display = 'none'; });
}

cartBtn.addEventListener('click', () => {
  cartDrawer.classList.add('open');
  cartOverlay.classList.add('open');
});

closeCart.addEventListener('click', () => {
  cartDrawer.classList.remove('open');
  cartOverlay.classList.remove('open');
});

cartOverlay.addEventListener('click', () => {
  cartDrawer.classList.remove('open');
  cartOverlay.classList.remove('open');
});