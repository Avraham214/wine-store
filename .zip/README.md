# Home Wine Online Store Backend

A RESTful API backend server for a home wine online store built with **Node.js**, **Express.js**, **Sequelize v6 ORM**, and **SQLite3**.

---

## Technical Stack & Architecture

- **Runtime**: Node.js (`"type": "module"`)
- **Web Framework**: Express.js
- **ORM**: Sequelize v6
- **Database**: SQLite3 (`./Database/db.sqlite`)
- **Middleware**: CORS, Express JSON parser, User Authentication Header Validator

---

## Project Structure

```text
.
├── Database/
│   ├── config.js               # Database connection & Sequelize configuration
│   ├── db.sqlite               # SQLite database file
│   ├── seed.js                 # Database seeder for sample users and wines
│   └── models/
│       ├── user.js             # User model
│       ├── wine.js             # Wine model & inventory management
│       ├── cartItem.js         # Cart Item model
│       ├── order.js            # Order model
│       ├── orderItem.js        # Order Items model
│       └── index.js            # Centralized Associations & Model Exports
├── Middlewares/
│   └── authMiddleware.js       # User ID / Authentication verification
├── Routes/
│   ├── wineRouter.js           # Public/Admin wine listing & detail routes
│   ├── cartRouter.js           # User cart management routes
│   └── orderRouter.js          # Order checkout transaction & stock deduction
├── index.js                    # Main server entry point
├── package.json                # Project dependencies and scripts
└── test.js                     # End-to-end integration test suite
```

---

## Installation & Setup

1. **Install Dependencies**:
   ```bash
   npm install
   ```

2. **Seed Initial Data**:
   Populates sample users (`user-001`, `admin-001`) and sample wines:
   ```bash
   npm run seed
   ```

3. **Start Server**:
   ```bash
   npm start
   # or with live reloading:
   npm run dev
   ```
   The server starts on `http://localhost:3000`.

4. **Run Integration Tests**:
   ```bash
   npm test
   ```

---

## Authentication

Cart and Order endpoints require an authentication header:
```http
user_id: user-001
```
If the header is missing or the ID is not found in the database, the server returns `401 Unauthorized`.

---

## API Endpoints

### 1. Wines (`/api/v1/wines`)

| Method | Endpoint | Access | Description |
|---|---|---|---|
| `GET` | `/api/v1/wines` | Public | Fetch all wines & inventory stock levels (supports `?type=`, `?sweetness=`, `?in_stock=true`) |
| `GET` | `/api/v1/wines/:id` | Public | Get wine details by ID |
| `POST` | `/api/v1/wines` | Admin/Public | Add a new wine bottle |

### 2. Cart (`/api/v1/cart`) *(Requires `user_id` header)*

| Method | Endpoint | Description |
|---|---|---|
| `GET` | `/api/v1/cart` | Retrieve current user's cart items with associated Wine details |
| `POST` | `/api/v1/cart` | Add wine or update quantity in cart. Body: `{"wine_id": 1, "quantity": 2}` |
| `DELETE` | `/api/v1/cart/:id` | Remove item from cart by CartItem ID |

### 3. Orders (`/api/v1/orders`) *(Requires `user_id` header)*

| Method | Endpoint | Description |
|---|---|---|
| `POST` | `/api/v1/orders` | Checkout current cart via a Sequelize Transaction: checks stock, creates Order & OrderItems, deducts stock, clears cart |
| `GET` | `/api/v1/orders` | List all historical orders for the current user |
| `GET` | `/api/v1/orders/:id` | Get order details with items and wine information |

---

## Sample Test Users

| User ID | Name | Role | Email |
|---|---|---|---|
| `user-001` | John Doe | Customer | `john.doe@example.com` |
| `admin-001` | Winery Manager | Admin | `manager@homewine.com` |
